<?php 
include ("library/db_config.php");

include ("library/loginfunctions.php");

include ("library/emails.php");

	$id = $_GET['item_number'];  
	$txn_id = $_GET['tx'];
	$payment_gross = $_GET['amt'];
	$currency_code = $_GET['cc'];
	$payment_status = $_GET['st'];
		
	// check whether the payment_status is Completed
	$isPaymentCompleted = false;
	if($payment_status == "Completed") {
		$isPaymentCompleted = true;
	}
	// check that txn_id has not been previously processed
	$isUniqueTxnId = false; 

		$stmt = $pdodb->prepare("SELECT * FROM nrna_members WHERE txn_id = ?");
		$data = array($txn_id);
		$stmt->execute($data);
		$count = $stmt->rowCount();

	if($count == 0) {
        $isUniqueTxnId = true;
	}	

	// check that receiver_email is your PayPal email
	// check that payment_amount/payment_currency are correct
	if($isPaymentCompleted && $isUniqueTxnId && $payment_gross == $_SESSION['pay_amount'] && $currency_code == "GBP") {

		$updQry = $pdodb->prepare("UPDATE nrna_members SET paid_amount = ?, payment_status = ?, txn_id = ? WHERE member_id = ?");
		$data = array($payment_gross, $payment_status, $txn_id, $id);
		$upd = $updQry->execute($data);

		/*** Send Confirmation email to members***/
		signupConfirm($_SESSION['emailArr']);

	}

?>

<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title></title>
      <!-- Stylesheets -->
	  <link href="css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/login.css">
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <!--Google Fonts-->
      <link href='https://fonts.googleapis.com/css?family=Playfair+Display' rel='stylesheet' type='text/css'>
      <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
   </head>
   <body>
      <div id="main-wrapper">
         <div class="cotn_principal">
               <div id="msform" style="width: auto;">				
                  <!-- fieldsets -->
                  <fieldset>

                     <h1 class="fs-title">Welcome to NRNA</h1>
            <div class="alert alert-success" style="margin: 10px;">
               <strong>Success!</strong> We have sent confirmation link to your Email ID.
            </div>

                     <p class="">
                         <img src="img/nrna-logo.jpg" width="100" height="100"></br></br>
                        You are successfully registered with us.</br></br>
                        <strong>Our online portal is under construction.</strong>
                     </p>                      
                  </fieldset>
               </div>
         </div>
      </div>
      <!-- end #main-wrapper -->

   </body>
</html>
