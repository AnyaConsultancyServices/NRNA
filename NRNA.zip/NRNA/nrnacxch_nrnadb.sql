-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2018 at 08:54 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nrnacxch_nrnadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `nrna_members`
--

CREATE TABLE `nrna_members` (
  `member_id` int(100) NOT NULL,
  `member_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `passport_num` varchar(255) NOT NULL,
  `member_relation` varchar(255) NOT NULL,
  `uk_address` longtext NOT NULL,
  `nepal_address` longtext NOT NULL,
  `passport_img` varchar(255) NOT NULL,
  `address_proof` varchar(255) NOT NULL,
  `mem_status` varchar(25) NOT NULL,
  `member_since` datetime NOT NULL,
  `created_by` int(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `paid_amount` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `txn_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `nrna_members`
--
ALTER TABLE `nrna_members`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nrna_members`
--
ALTER TABLE `nrna_members`
  MODIFY `member_id` int(100) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
