<?php 

	if(!isset($_SESSION))
	{
		@session_start();
	}

	$mysql_ip = 'localhost';
	$mysql_user = 'nrnacxch';
	$mysql_pass = 'El;k{-!d_Br6';
	$mysql_db = 'nrnacxch_nrnadb';

	$pdodb = new PDO("mysql:host=$mysql_ip;dbname=$mysql_db", $mysql_user, $mysql_pass);

	date_default_timezone_set('Europe/London');
	//date_default_timezone_set('asia/kolkata');

	define('BASE_PATH', 'http://nrna.co.uk/dev');

	if(isset($ajaxcall)){
		include('../helper.php');
	} else { 
		include('helper.php'); 
	}

?>